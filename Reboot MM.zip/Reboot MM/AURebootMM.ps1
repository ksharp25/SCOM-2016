﻿#===============================================================================#
#  AURebootMM.ps1                                                               #
#  PowerShell script to put SCOM agent in maintenance mode after system reboot  #  
#  If the server is a member of a Cluster, the entire cluster goes into MM      #
#  Original Script and Author: Start-MaintenanceMode.ps1 by Jeremy Engel        #
#  Modified by Kevin M. Sharp                                                   #
#  Last Modified: September 26, 2018                                            #
#  Version 1.2.9                                                                #
#===============================================================================#

#Get SCOM Alert Parameters
$RootMS = "<Management Server hostname>"
$Minutes = 60
$Logfile = "C:\MMLog\<filename>.log"

#Hashtable for Reason Codes
$Specialcodes = @{"Application: Installation (Planned)"="ApplicationInstallation";
            "Loss of network connectivity (Unplanned)"="LossOfNetworkConnectivity";
            "Operating System: Recovery (Planned)"="UnplannedOther";
            "Application Maintenance (Unplanned)"="UnplannedOther";
            "No title for this reason could be found"="PlannedOther";
            "Other (Planned)"="PlannedOther";
            "Hardware: Maintenance (Planned)"="PlannedHardwareMaintenance";
            "Hardware: Installation (Planned)"="PlannedHardwareInstallation";
            "Operating System: Reconfiguration (Planned)"="PlannedOperatingSystemReconfiguration";
            "Application: Maintenance (Planned)"="PlannedApplicationMaintenance";
            "Hardware: Maintenance (Unplanned)"="UnplannedHardwareMaintenance";
            "Hardware: Installation (Unplanned)"="UnplannedHardwareInstallation";
            "Operating System: Reconfiguration (Unplanned)"="UnplannedOperatingSystemReconfiguration";
            "Other (Unplanned)"="UnplannedOther";
            "Application: Unresponsive"="ApplicationUnresponsive";
            "Application: Unstable"="ApplicationUnstable";
            "Security Issue"="SecurityIssue";}

#Setting Up SCOM Alert
Import-Module 'C:\Program Files\Microsoft System Center 2016\Operations Manager\Powershell\OperationsManager\OperationsManager.psm1'
Add-PSSnapin Microsoft.EnterpriseManagement.OperationsManager.Client -ErrorAction SilentlyContinue
New-ManagementGroupConnection -ConnectionString $RootMS
Set-Location OperationsManagerMonitoring::

#Logging Function to Update Log Files
Function LogWrite
{
    Param([string]$logstring)
    Add-Content $Logfile -Value $logstring
}

#Parsing Alert Parameters
$startTime = (Get-Date).ToLocalTime()
$endTime = $startTime.AddMinutes($Minutes)
$alert = Get-SCOMAlert -ResolutionState 0 -Name "Reboot Detected (Start Maintenance Mode)"

#Setting Maintenance Mode Parameters for Computer Object
foreach ($a in $alert)
{
    $agent = Get-SCOMAgent | Where-Object { $_.DisplayName -eq $a.MonitoringObjectDisplayName }
    $alertid = $a.Id
    $descr = $a.Description
    $Server = $a.NetbiosComputerName
    $user = $a.Description | Select-String -Pattern "(?<=of user)(.*?)(?=for)"
    $reas = $a.Description | Select-String -Pattern "(?<=following reason: )(.*)"
    $shutd = $a.Description | Select-String -Pattern "(?<=shutdown type: )(.*)"
    $comm = $a.Description | Select-String -Pattern "(?<=comment: )(.*)"

    #Formatting Variable for Maintenance Mode
    $reason1 = $reas.Matches[0].Value.ToString()
    $username = $user.Matches[0].Value.ToString()
    $shutdowntype = $shutd.Matches[0].Value.ToString()
    if ($comm.Matches[0].Value -eq $null)
    {
        $comment1 = "$username has initiated a $shutdowntype of $Server with no comment provided"
    }
    else
    {
        $comment = $comm.Matches[0].Value.ToString()
        $comment1 = "$username has initiated a $shutdowntype of $Server with the following comment: $comment"
    }

    #Checking Reason against Hashtable
    if ($Specialcodes.ContainsKey($reason1)){$reason1 = $Specialcodes[$reason1]}
    else{$reason1 = "PlannedOther"}

    #Place Object in Maintenance Mode
    if (($clusters = $agent.GetRemotelyManagedComputers()))
    {
        $clusterNodeClass = Get-MonitoringClass -Name Microsoft.Windows.Cluster.Node
        foreach ($cluster in $clusters)
        {
            $clusterObj = Get-MonitoringClass -Name Microsoft.Windows.Cluster | Get-MonitoringObject -Criteria "Name='$($cluster.ComputerName)'"
            if ($clusterObj)
            {
                $clusterObj.ScheduleMaintenanceMode($startTime,$endTime,$reason1,$comment1,"Recursive")
                $nodes = $clusterObj.GetRelatedMonitoringObjects($clusterNodeClass)
                if ($nodes)
                {
                    foreach ($node in $nodes)
                    {
                        LogWrite "$startTime; Putting $node NODE into maintenance mode for $Minutes minutes. AlertID: $alertid" -ForeGroundColor Green
                    }
                }
            }
            LogWrite "$startTime; Putting $($cluster.Computer) CLUSTER into maintenance mode for $Minutes minutes. AlertID: $alertid" -ForeGroundColor Green
            New-MaintenanceWindow -StartTime $startTime -EndTime $endTime -MonitoringObject $cluster.Computer -Reason $reason1 -Comment $comment1
            Set-SCOMAlert -Alert $a -ResolutionState 249
        }
        LogWrite "$startTime; Putting $Server into maintenance mode for $Minutes minutes. AlertID: $alertid" -ForeGroundColor Green
        New-MaintenanceWindow -StartTime $startTime -EndTime $endTime -MonitoringObject $agent.HostComputer -Reason $reason1 -Comment $comment1
        Set-SCOMAlert -Alert $a -ResolutionState 249
    }
    LogWrite "$startTime; Putting $Server into maintenance mode for $Minutes minutes. AlertID: $alertid" -ForeGroundColor Green
    New-MaintenanceWindow -StartTime $startTime -EndTime $endTime -MonitoringObject $agent.HostComputer -Reason $reason1 -Comment $comment1
    Set-SCOMAlert -Alert $a -ResolutionState 249
}