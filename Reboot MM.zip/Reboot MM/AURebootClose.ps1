﻿#===============================================================================#
#  AURebootClose.ps1                                                            #
#  PowerShell script to close alerts generated from the Reboot Server Rule      #  
#  Original Script and Author: Kevin M. Sharp                                   #
#  Last Modified: September 26, 2018                                            #
#  Version 1.2.9                                                                #
#===============================================================================#

#Load SCOM Snap-In
Import-Module 'C:\Program Files\Microsoft System Center 2016\Operations Manager\Powershell\OperationsManager\OperationsManager.psm1'
Add-PSSnapin Microsoft.EnterpriseManagement.OperationsManager.Client

#Connect to SCOM
New-ManagementGroupConnection -ConnectionString "<RMS Server hostname>"
Set-Location OperationsManagerMonitoring::

# Update and Close Alert
Get-SCOMAlert -Criteria "ResolutionState = 249 and Name LIKE 'Reboot Detected%'" | Set-SCOMAlert -ResolutionState 255