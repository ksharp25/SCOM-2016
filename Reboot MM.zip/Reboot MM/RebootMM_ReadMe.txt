========================================================================================
RebootMM ReadMe
========================================================================================

For detailed instructions, refer the the Setup Guide Document.

Basic Sequence of steps:

1) Copy AURebootMM.ps1 script file to the C:\Scripts directory on all RMS (Management Servers) in your SCOM environment.
2) Create the Command Notification Channel pointing to AURebootMM.ps1 script
3) Create the Subscriber for the Command Channel (RebootMM)
4) Create and Enable the subscription for the Server Reboot alerts
5) Copy the AURebootClose.ps1 script to the C:\Scripts directory on all RMS (Management Servers) in your SCOM environment.
6) Create the Command Notification Channel poingint to AURebootClose.ps1 script
7) Create the Subscriber for the Command Channel (RebootClose)
8) Create and Enable the subscription for the Close Reboot alerts.